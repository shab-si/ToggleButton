import React, { Component } from 'react';
import Sidbar from './Sidebar';
import Boxes from './Boxes'

export default class Main extends Component {

    state = {
        boxes: [
            { id: 1, title: 'Box 1', ax: 'images/1.jpg', pricegoods:'125000'},
            { id: 2, title: 'Box 2', ax: 'images/2.jpg', pricegoods:'255000'},
            { id: 3, title: 'Box 3', ax: 'images/3.jpg', pricegoods:'170000'},
            { id: 4, title: 'Box 4', ax: 'images/4.jpg', pricegoods:'330000'},
        ],
        activeBoxes: [1, 2, 3, 4]
    }

    // arrow function
    handelToggleBtn = (id) => {
        const activeBoxes = [...this.state.activeBoxes];

        if (activeBoxes.includes(id)) {
            activeBoxes.splice(activeBoxes.indexOf(id), 1)
        } else {
            activeBoxes.push(id);
        }

        this.setState(state => {
            return {
                ...state,
                activeBoxes
            }
        })
    }

    render() {
        return (
            <>
                <Sidbar
                    handeleToggle={this.handelToggleBtn}  // this is for arrow function
                    boxes={this.state.boxes}
                    activeBoxes={this.state.activeBoxes} />
                <Boxes
                    boxes={this.state.boxes}
                    activeBoxes={this.state.activeBoxes} />
            </>
        )
    }
}
