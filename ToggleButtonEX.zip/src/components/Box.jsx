import React from 'react'
import Image from './Image'
import Price from './Price'


export default function Box(props) {
    return (
        <div className="box">
            {props.title}
            {/* call Image and Price components */}
            <Image ax={props.ax}  />
            <Price pricegoods={props.pricegoods} />
        </div>
    )
}
