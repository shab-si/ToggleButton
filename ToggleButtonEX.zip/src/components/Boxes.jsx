import React from 'react'
import Box from './Box'

export default function Boxes(props) {
    const boxes = props.boxes.map(box => {
        if (props.activeBoxes.includes(box.id)) {
            {/* call Box component */}
            return <Box 
                title={box.title}  
                ax={box.ax} 
                pricegoods={box.pricegoods}
                />
        }

    })
    return (
        <div className="box-wrapper">
            {boxes}
        </div>
    )
}
